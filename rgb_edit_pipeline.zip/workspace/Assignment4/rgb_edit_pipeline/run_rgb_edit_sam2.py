#!/usr/bin/env python3
"""Seedream background editing with manually prompted SAM2 video masks."""

from __future__ import annotations

import argparse
import gc
import json
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import numpy as np
import zarr
from PIL import Image

from run_rgb_edit import (
    SAM3_ROOT,
    SEEDREAM_MODEL,
    Seedream,
    PipelineError,
    append_jsonl,
    choice_for_episode,
    chw_to_hwc,
    completed_episodes,
    draw_qa,
    hwc_to_chw,
    parse_episodes,
    setup_output,
    write_jpegs,
)

SAM2_ROOT = Path("/workspace/models/sam2")
SAM2_CHECKPOINT = SAM2_ROOT / "checkpoints/sam2.1_hiera_large.pt"
SAM2_CONFIG = "configs/sam2.1/sam2.1_hiera_l.yaml"
TARGETS = ("right_arm", "hammer", "green_cube")
OBJECT_IDS = {"right_arm": 1, "hammer": 2, "green_cube": 3}


def load_manual_points(path: Path, episodes: list[int]) -> dict[int, dict[str, list[list[int]]]]:
    if not path.is_file():
        raise PipelineError(f"Manual point file does not exist: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        stored = payload["episodes"]
    except (OSError, ValueError, KeyError) as exc:
        raise PipelineError(f"Invalid manual point JSON: {path}") from exc
    result: dict[int, dict[str, list[list[int]]]] = {}
    for episode in episodes:
        item = stored.get(str(episode))
        if not isinstance(item, dict):
            raise PipelineError(f"No manual SAM2 points for episode {episode}")
        result[episode] = {}
        for target in TARGETS:
            points = item.get(target)
            if not isinstance(points, list) or not any(len(point) == 3 and int(point[2]) == 1 for point in points):
                raise PipelineError(f"Episode {episode} target {target!r} needs at least one positive point")
            result[episode][target] = [[int(point[0]), int(point[1]), int(point[2])] for point in points]
    return result


def cache_path(mask_cache_dir: Path, episode: int, target: str) -> Path:
    return mask_cache_dir / f"episode_{episode:04d}_{target}.npz"


def load_cached_masks(
    mask_cache_dir: Path | None,
    episode: int,
    frame_count: int,
    height: int,
    width: int,
    prompts: dict[str, list[list[int]]],
) -> dict[str, np.ndarray] | None:
    if mask_cache_dir is None:
        return None
    masks: dict[str, np.ndarray] = {}
    for target in TARGETS:
        path = cache_path(mask_cache_dir, episode, target)
        if not path.is_file():
            return None
        try:
            data = np.load(path)
            cached_points = data["points"].astype(int).tolist()
            mask = data["mask"].astype(bool)
        except Exception:
            return None
        if cached_points != prompts[target] or mask.shape != (frame_count, height, width):
            return None
        masks[target] = mask
    return masks


def save_cached_masks(
    mask_cache_dir: Path | None,
    episode: int,
    masks: dict[str, np.ndarray],
    prompts: dict[str, list[list[int]]],
) -> None:
    if mask_cache_dir is None:
        return
    mask_cache_dir.mkdir(parents=True, exist_ok=True)
    for target, mask in masks.items():
        np.savez_compressed(
            cache_path(mask_cache_dir, episode, target),
            mask=mask,
            points=np.asarray(prompts[target], dtype=np.int32),
        )


class Sam2Tracker:
    def __init__(self, checkpoint: Path, config: str) -> None:
        if not checkpoint.is_file():
            raise PipelineError(f"SAM2 checkpoint not found: {checkpoint}")
        if str(SAM2_ROOT) not in sys.path:
            sys.path.insert(0, str(SAM2_ROOT))
        try:
            import torch
            from sam2.build_sam import build_sam2_video_predictor
        except ModuleNotFoundError as exc:
            raise PipelineError("Run this script in the sam2 conda environment.") from exc
        if not torch.cuda.is_available():
            raise PipelineError("SAM2 requires a CUDA-visible GPU.")
        self.torch = torch
        self.predictor = build_sam2_video_predictor(
            config_file=config,
            ckpt_path=str(checkpoint),
            device="cuda",
            apply_postprocessing=True,
        )

    def track(
        self,
        frames_dir: Path,
        frame_count: int,
        height: int,
        width: int,
        prompts: dict[str, list[list[int]]],
    ) -> dict[str, np.ndarray]:
        result = {target: np.zeros((frame_count, height, width), dtype=bool) for target in TARGETS}
        state: dict[str, Any] | None = None
        try:
            with self.torch.inference_mode(), self.torch.autocast("cuda", dtype=self.torch.bfloat16):
                state = self.predictor.init_state(
                    video_path=str(frames_dir),
                    offload_video_to_cpu=True,
                    offload_state_to_cpu=True,
                    async_loading_frames=False,
                )
                for target in TARGETS:
                    points = prompts[target]
                    xy = np.asarray([[point[0], point[1]] for point in points], dtype=np.float32)
                    labels = np.asarray([point[2] for point in points], dtype=np.int32)
                    self.predictor.add_new_points_or_box(
                        inference_state=state,
                        frame_idx=0,
                        obj_id=OBJECT_IDS[target],
                        points=xy,
                        labels=labels,
                        clear_old_points=True,
                        normalize_coords=True,
                    )
                for frame_idx, object_ids, mask_logits in self.predictor.propagate_in_video(state):
                    logits = mask_logits.detach().float().cpu().numpy()
                    if logits.ndim == 4:
                        logits = logits[:, 0]
                    for position, object_id in enumerate(object_ids):
                        target = next(name for name, value in OBJECT_IDS.items() if value == int(object_id))
                        result[target][int(frame_idx)] = logits[position] > 0.0
        except Exception as exc:
            raise PipelineError(f"SAM2 tracking failed: {type(exc).__name__}: {exc}") from exc
        finally:
            if state is not None:
                try:
                    self.predictor.reset_state(state)
                except Exception:
                    pass
        return result

    def close(self) -> None:
        self.predictor = None
        gc.collect()
        self.torch.cuda.empty_cache()


def run_episode(
    *,
    episode: int,
    start: int,
    end: int,
    input_rgb: Any,
    output_rgb: Any,
    tracker: Sam2Tracker,
    prompts: dict[str, list[list[int]]],
    seedream: Seedream | None,
    choice: dict[str, Any],
    work: Path,
    save_masks: bool,
    mask_cache_dir: Path | None,
) -> dict[str, Any]:
    original = chw_to_hwc(np.asarray(input_rgb[start:end], dtype=np.uint8))
    if not len(original):
        raise PipelineError(f"Episode {episode} has no frames")
    masks = load_cached_masks(
        mask_cache_dir,
        episode,
        len(original),
        int(original.shape[1]),
        int(original.shape[2]),
        prompts,
    )
    # All prompts are validated before this paid call.
    if seedream:
        background, metadata = seedream.edit(original[0], choice["prompt"])
        edit_source = "seedream"
    else:
        background, metadata, edit_source = original[0].copy(), None, "original_first_frame_sam2_validation"

    used_mask_cache = masks is not None
    if masks is None:
        temporary_parent = work / "tmp_frames"
        temporary_parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=f"episode_{episode:04d}_", dir=temporary_parent) as temporary:
            frames_dir = Path(temporary)
            write_jpegs(original, frames_dir)
            masks = tracker.track(frames_dir, len(original), *original.shape[1:3], prompts)
        save_cached_masks(mask_cache_dir, episode, masks, prompts)
    protected = masks["right_arm"] | masks["hammer"] | masks["green_cube"]
    if not protected[0].any():
        raise PipelineError(f"SAM2 found no protected pixels for episode {episode}")
    # Deliberately hard composite: protected pixels are original; all remaining
    # pixels are exactly the Seedream background plate, without feathering.
    final = np.where(protected[..., None], original, background[None]).astype(np.uint8)
    if not np.array_equal(final[protected], original[protected]):
        raise PipelineError(f"Episode {episode}: protected pixels changed during compositing")
    output_rgb[start:end] = hwc_to_chw(final)

    edited_dir = work / "edited_first_frames"
    edited_dir.mkdir(parents=True, exist_ok=True)
    Image.fromarray(background).save(edited_dir / f"episode_{episode:04d}.png")
    draw_qa(
        original,
        background,
        final,
        protected,
        work / "qa" / f"episode_{episode:04d}.jpg",
        f"SAM2 manual prompts | hard protected right arm / hammer / cube",
    )
    if save_masks:
        mask_dir = work / "masks"
        mask_dir.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(mask_dir / f"episode_{episode:04d}.npz", **masks)
    return {
        "frames": len(original),
        "edit_source": edit_source,
        "seedream": metadata,
        "sam2_points": prompts,
        "sam2_first_areas": {target: int(mask[0].sum()) for target, mask in masks.items()},
        "sam2_missing_frames": {
            target: int((~mask.reshape(len(mask), -1).any(axis=1)).sum()) for target, mask in masks.items()
        },
        "sam2_mask_source": "preview_cache" if used_mask_cache else "propagated",
        "composite": "original_on_mask_else_seedream_background",
    }


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--input-zarr", required=True, type=Path)
    result.add_argument("--output-zarr", required=True, type=Path)
    selection = result.add_mutually_exclusive_group(required=True)
    selection.add_argument("--episodes", type=parse_episodes, help="For example: 0,2,10-12")
    selection.add_argument("--all-episodes", action="store_true")
    result.add_argument("--points-json", required=True, type=Path)
    result.add_argument("--seed", type=int, default=20260620)
    result.add_argument("--use-seedream", action="store_true")
    result.add_argument("--seedream-model", default=SEEDREAM_MODEL)
    result.add_argument("--seedream-timeout", type=int, default=300)
    result.add_argument("--sam2-checkpoint", type=Path, default=SAM2_CHECKPOINT)
    result.add_argument("--sam2-config", default=SAM2_CONFIG)
    result.add_argument("--mask-cache-dir", type=Path)
    result.add_argument("--save-masks", action="store_true")
    result.add_argument("--overwrite-output", action="store_true")
    return result


def main() -> int:
    args = parser().parse_args()
    input_path, output_path = args.input_zarr.resolve(), args.output_zarr.resolve()
    if input_path == output_path:
        raise PipelineError("Input and output Zarr paths must differ")
    if args.mask_cache_dir is None:
        args.mask_cache_dir = output_path.with_name(output_path.stem + "_sam2_mask_cache")
    source_preview = zarr.open_group(str(input_path), mode="r")
    ends = np.asarray(source_preview["meta/episode_ends"][:], dtype=int)
    starts = np.concatenate(([0], ends[:-1]))
    episodes = list(range(len(ends))) if args.all_episodes else args.episodes
    assert episodes is not None
    invalid = [episode for episode in episodes if episode < 0 or episode >= len(ends)]
    if invalid:
        raise PipelineError(f"Invalid episode ids: {invalid}")
    points = load_manual_points(args.points_json.resolve(), episodes)

    work = output_path.with_name(output_path.stem + "_rgbedit_work")
    work.mkdir(parents=True, exist_ok=True)
    (work / "run_config.json").write_text(json.dumps({
        "input_zarr": str(input_path),
        "output_zarr": str(output_path),
        "uses_seedream": args.use_seedream,
        "seedream_model": args.seedream_model if args.use_seedream else None,
        "segmenter": "sam2_manual_points",
        "sam2_checkpoint": str(args.sam2_checkpoint),
        "sam2_config": args.sam2_config,
        "mask_cache_dir": str(args.mask_cache_dir.resolve()) if args.mask_cache_dir else None,
        "points_json": str(args.points_json.resolve()),
        "composite": "original_on_mask_else_seedream_background",
    }, indent=2) + "\n", encoding="utf-8")
    manifest = work / "manifest.jsonl"
    done = completed_episodes(manifest)
    source, destination = setup_output(input_path, output_path, args.overwrite_output)
    seedream = Seedream(args.seedream_timeout, args.seedream_model) if args.use_seedream else None
    tracker = Sam2Tracker(args.sam2_checkpoint.resolve(), args.sam2_config)
    try:
        for episode in episodes:
            if episode in done:
                print(f"episode={episode:04d} completed already; skip")
                continue
            choice = choice_for_episode(args.seed, episode)
            record = {
                "episode": episode,
                "start_frame": int(starts[episode]),
                "end_frame": int(ends[episode]),
                "domain": choice,
                "started_at_unix": time.time(),
            }
            append_jsonl(manifest, {**record, "status": "running"})
            try:
                result = run_episode(
                    episode=episode,
                    start=int(starts[episode]),
                    end=int(ends[episode]),
                    input_rgb=source["data/head_camera"],
                    output_rgb=destination["data/head_camera"],
                    tracker=tracker,
                    prompts=points[episode],
                    seedream=seedream,
                    choice=choice,
                    work=work,
                    save_masks=args.save_masks,
                    mask_cache_dir=args.mask_cache_dir.resolve() if args.mask_cache_dir else None,
                )
                append_jsonl(manifest, {**record, **result, "status": "completed", "finished_at_unix": time.time()})
                print(f"episode={episode:04d} completed")
            except Exception as exc:
                append_jsonl(manifest, {
                    **record, "status": "failed", "finished_at_unix": time.time(),
                    "error": f"{type(exc).__name__}: {exc}",
                })
                raise
    finally:
        tracker.close()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except PipelineError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
