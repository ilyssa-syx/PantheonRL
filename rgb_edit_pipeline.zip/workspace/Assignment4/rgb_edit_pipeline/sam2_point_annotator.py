#!/usr/bin/env python3
"""Browser UI for manually placing SAM2 positive/negative prompts on episode frame 0."""

from __future__ import annotations

import argparse
import gc
import json
import sys
import tempfile
from pathlib import Path
from typing import Any

import gradio as gr
import numpy as np
import zarr
from PIL import Image, ImageDraw


TARGETS = ("right_arm", "hammer", "green_cube")
COLOURS = {"right_arm": "#ff4d4d", "hammer": "#40a9ff", "green_cube": "#52c41a"}
SAM2_ROOT = Path("/workspace/models/sam2")
SAM2_CHECKPOINT = SAM2_ROOT / "checkpoints/sam2.1_hiera_large.pt"
SAM2_CONFIG = "configs/sam2.1/sam2.1_hiera_l.yaml"


def parse_episodes(value: str) -> list[int]:
    result: list[int] = []
    for token in value.split(","):
        start_end = token.strip().split("-", 1)
        if len(start_end) == 1:
            result.append(int(start_end[0]))
        else:
            start, end = map(int, start_end)
            result.extend(range(start, end + 1))
    return sorted(set(result))


def empty_annotations(input_zarr: Path, episodes: list[int]) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "input_zarr": str(input_zarr.resolve()),
        "episodes": {str(episode): {target: [] for target in TARGETS} for episode in episodes},
    }


def load_annotations(path: Path, input_zarr: Path, episodes: list[int]) -> dict[str, Any]:
    if path.is_file():
        data = json.loads(path.read_text(encoding="utf-8"))
    else:
        data = empty_annotations(input_zarr, episodes)
    data.setdefault("schema_version", 1)
    data.setdefault("input_zarr", str(input_zarr.resolve()))
    data.setdefault("episodes", {})
    for episode in episodes:
        item = data["episodes"].setdefault(str(episode), {})
        for target in TARGETS:
            item.setdefault(target, [])
    return data


def chw_to_hwc(value: np.ndarray) -> np.ndarray:
    return np.moveaxis(value, 1, -1)


def write_jpegs(frames: np.ndarray, directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    for index, frame in enumerate(frames):
        Image.fromarray(frame).save(directory / f"{index:05d}.jpg", quality=100, subsampling=0)


def mask_overlay(frame: np.ndarray, mask: np.ndarray, colour: tuple[int, int, int]) -> np.ndarray:
    result = frame.astype(np.float32).copy()
    result[mask] = result[mask] * 0.45 + np.asarray(colour, dtype=np.float32) * 0.55
    return np.clip(result, 0, 255).astype(np.uint8)


def preview_sheet(frames: np.ndarray, masks: np.ndarray, title: str) -> Image.Image:
    if len(frames) == 0:
        raise ValueError("No frames to preview")
    sample_count = min(6, len(frames))
    indices = np.linspace(0, len(frames) - 1, sample_count, dtype=int)
    colour = (255, 30, 30)
    tiles = []
    for frame_index in indices:
        tile = Image.fromarray(mask_overlay(frames[frame_index], masks[frame_index], colour))
        draw = ImageDraw.Draw(tile)
        draw.rectangle((0, 0, 190, 26), fill=(0, 0, 0))
        draw.text(
            (6, 5),
            f"f={frame_index} area={int(masks[frame_index].sum())}",
            fill=(255, 255, 255),
        )
        tiles.append(tile)
    width, height = tiles[0].size
    sheet = Image.new("RGB", (width * 3, height * 2 + 28), "white")
    draw = ImageDraw.Draw(sheet)
    draw.text((6, 6), title, fill=(0, 0, 0))
    for position, tile in enumerate(tiles):
        x = (position % 3) * width
        y = 28 + (position // 3) * height
        sheet.paste(tile, (x, y))
    return sheet


def point_summary(points: dict[str, list[list[int]]]) -> str:
    lines: list[str] = []
    for target in TARGETS:
        lines.append(f"{target}:")
        target_points = points.get(target, [])
        if not target_points:
            lines.append("  no points")
            continue
        for index, point in enumerate(target_points, start=1):
            x, y, label = map(int, point)
            sign = "+" if label == 1 else "-"
            role = "positive/object" if label == 1 else "negative/background"
            lines.append(f"  {index}. {sign} ({x}, {y}) {role}")
    return "\n".join(lines)


class Sam2Previewer:
    def __init__(self, checkpoint: Path, config: str, device: str) -> None:
        if not checkpoint.is_file():
            raise RuntimeError(f"SAM2 checkpoint not found: {checkpoint}")
        if str(SAM2_ROOT) not in sys.path:
            sys.path.insert(0, str(SAM2_ROOT))
        import torch
        from sam2.build_sam import build_sam2_video_predictor

        if not torch.cuda.is_available() and device.startswith("cuda"):
            raise RuntimeError("SAM2 preview needs a CUDA-visible GPU")
        self.torch = torch
        self.predictor = build_sam2_video_predictor(
            config_file=config,
            ckpt_path=str(checkpoint),
            device=device,
            apply_postprocessing=True,
        )

    def preview(self, frames: np.ndarray, points: list[list[int]]) -> np.ndarray:
        if not any(int(point[2]) == 1 for point in points):
            raise RuntimeError("Current target needs at least one positive point before preview")
        masks = np.zeros(frames.shape[:3], dtype=bool)
        state: dict[str, Any] | None = None
        with tempfile.TemporaryDirectory(prefix="sam2_preview_") as temporary:
            frames_dir = Path(temporary)
            write_jpegs(frames, frames_dir)
            try:
                with self.torch.inference_mode(), self.torch.autocast("cuda", dtype=self.torch.bfloat16):
                    state = self.predictor.init_state(
                        video_path=str(frames_dir),
                        offload_video_to_cpu=True,
                        offload_state_to_cpu=True,
                        async_loading_frames=False,
                    )
                    xy = np.asarray([[point[0], point[1]] for point in points], dtype=np.float32)
                    labels = np.asarray([point[2] for point in points], dtype=np.int32)
                    self.predictor.add_new_points_or_box(
                        inference_state=state,
                        frame_idx=0,
                        obj_id=1,
                        points=xy,
                        labels=labels,
                        clear_old_points=True,
                        normalize_coords=True,
                    )
                    for frame_idx, _object_ids, mask_logits in self.predictor.propagate_in_video(state):
                        logits = mask_logits.detach().float().cpu().numpy()
                        if logits.ndim == 4:
                            logits = logits[:, 0]
                        if logits.size:
                            masks[int(frame_idx)] = logits[0] > 0.0
            finally:
                if state is not None:
                    try:
                        self.predictor.reset_state(state)
                    except Exception:
                        pass
                gc.collect()
                if hasattr(self.torch, "cuda"):
                    self.torch.cuda.empty_cache()
        return masks


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-zarr", required=True, type=Path)
    parser.add_argument("--episodes", default="0-4", type=parse_episodes)
    parser.add_argument("--output-json", required=True, type=Path)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7861)
    parser.add_argument("--share", action="store_true")
    parser.add_argument("--sam2-checkpoint", type=Path, default=SAM2_CHECKPOINT)
    parser.add_argument("--sam2-config", default=SAM2_CONFIG)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--preview-max-frames", type=int, default=0)
    parser.add_argument("--mask-cache-dir", type=Path)
    args = parser.parse_args()
    if args.mask_cache_dir is None:
        args.mask_cache_dir = args.output_json.with_name(args.output_json.stem + "_mask_cache")

    group = zarr.open_group(str(args.input_zarr), mode="r")
    ends = np.asarray(group["meta/episode_ends"][:], dtype=int)
    starts = np.concatenate(([0], ends[:-1]))
    if any(episode < 0 or episode >= len(ends) for episode in args.episodes):
        raise ValueError(f"Episode must be in [0, {len(ends) - 1}]")
    rgb = group["data/head_camera"]
    annotations = load_annotations(args.output_json, args.input_zarr, args.episodes)
    previewer: Sam2Previewer | None = None

    def save_annotations(state: dict[str, Any]) -> str:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
        return f"Saved points to {args.output_json}"

    def episode_image(episode: int, state: dict[str, Any]) -> Image.Image:
        frame = np.moveaxis(np.asarray(rgb[int(starts[episode])], dtype=np.uint8), 0, -1)
        image = Image.fromarray(frame).convert("RGB")
        draw = ImageDraw.Draw(image)
        for target in TARGETS:
            for x, y, label in state["episodes"][str(episode)][target]:
                colour = COLOURS[target] if int(label) else "#ffd666"
                radius = 5
                draw.ellipse((x - radius, y - radius, x + radius, y + radius), outline=colour, width=3)
        return image

    def render(episode: str, state: dict[str, Any]) -> tuple[Image.Image, str]:
        return episode_image(int(episode), state), point_summary(state["episodes"][str(episode)])

    def add_point(
        episode: str,
        target: str,
        label_mode: str,
        state: dict[str, Any],
        event: gr.SelectData,
    ) -> tuple[Image.Image, dict[str, Any], str, str]:
        x, y = map(int, event.index)
        label = 1 if label_mode == "positive / object" else 0
        state["episodes"][str(episode)][target].append([x, y, label])
        status = save_annotations(state)
        return episode_image(int(episode), state), state, point_summary(state["episodes"][str(episode)]), status

    def undo(episode: str, target: str, state: dict[str, Any]) -> tuple[Image.Image, dict[str, Any], str, str]:
        points = state["episodes"][str(episode)][target]
        if points:
            points.pop()
        status = save_annotations(state)
        return episode_image(int(episode), state), state, point_summary(state["episodes"][str(episode)]), status

    def clear(episode: str, target: str, state: dict[str, Any]) -> tuple[Image.Image, dict[str, Any], str, str]:
        state["episodes"][str(episode)][target] = []
        status = save_annotations(state)
        return episode_image(int(episode), state), state, point_summary(state["episodes"][str(episode)]), status

    def preview_mask(
        episode: str,
        target: str,
        state: dict[str, Any],
    ) -> tuple[Image.Image | None, str]:
        nonlocal previewer
        episode_index = int(episode)
        start, end = int(starts[episode_index]), int(ends[episode_index])
        if args.preview_max_frames > 0:
            end = min(end, start + args.preview_max_frames)
        frames = chw_to_hwc(np.asarray(rgb[start:end], dtype=np.uint8))
        points = state["episodes"][str(episode_index)][target]
        try:
            if previewer is None:
                previewer = Sam2Previewer(args.sam2_checkpoint.resolve(), args.sam2_config, args.device)
            masks = previewer.preview(frames, points)
            args.mask_cache_dir.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(
                args.mask_cache_dir / f"episode_{episode_index:04d}_{target}.npz",
                mask=masks,
                points=np.asarray(points, dtype=np.int32),
            )
            missing = int((~masks.reshape(len(masks), -1).any(axis=1)).sum())
            first_area = int(masks[0].sum())
            sheet = preview_sheet(
                frames,
                masks,
                f"{target} SAM2 preview | first_area={first_area} missing_frames={missing}/{len(masks)}",
            )
            return sheet, (
                f"Previewed and cached {target}: first_area={first_area}, "
                f"missing_frames={missing}/{len(masks)}"
            )
        except Exception as exc:
            return None, f"Preview failed: {type(exc).__name__}: {exc}"

    first_episode = str(args.episodes[0])
    with gr.Blocks(title="RobotWin SAM2 manual point prompts") as app:
        gr.Markdown(
            "# SAM2 manual point prompts\n"
            "Choose an episode and target. Click **positive / object** on the object; use "
            "a negative click only to exclude adjacent tabletop/background. Save after all "
            "three targets have at least one positive point."
        )
        state = gr.State(annotations)
        with gr.Row():
            episode = gr.Dropdown(choices=[str(item) for item in args.episodes], value=first_episode, label="Episode")
            target = gr.Radio(TARGETS, value="right_arm", label="Target")
            label_mode = gr.Radio(["positive / object", "negative / background"], value="positive / object", label="Click type")
        image = gr.Image(value=episode_image(int(first_episode), annotations), type="pil", interactive=False, label="Frame 0 — click to add prompt")
        points_text = gr.Textbox(
            value=point_summary(annotations["episodes"][first_episode]),
            label="Current episode prompts",
            lines=12,
            interactive=False,
        )
        preview = gr.Image(type="pil", interactive=False, label="SAM2 mask preview")
        with gr.Row():
            preview_button = gr.Button("Preview current target mask")
            undo_button = gr.Button("Undo target click")
            clear_button = gr.Button("Clear target")
        status = gr.Textbox(label="Status", interactive=False)

        episode.change(render, inputs=[episode, state], outputs=[image, points_text])
        image.select(add_point, inputs=[episode, target, label_mode, state], outputs=[image, state, points_text, status])
        preview_button.click(preview_mask, inputs=[episode, target, state], outputs=[preview, status])
        undo_button.click(undo, inputs=[episode, target, state], outputs=[image, state, points_text, status])
        clear_button.click(clear, inputs=[episode, target, state], outputs=[image, state, points_text, status])

    app.launch(server_name=args.host, server_port=args.port, share=args.share)


if __name__ == "__main__":
    main()
