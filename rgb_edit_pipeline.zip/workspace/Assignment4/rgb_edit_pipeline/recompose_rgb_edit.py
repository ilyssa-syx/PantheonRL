#!/usr/bin/env python3
"""Recompose completed RGB-edited episodes without another Seedream request."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import zarr
from PIL import Image

from run_rgb_edit import (
    chw_to_hwc,
    composite_background,
    draw_qa,
    hwc_to_chw,
    parse_episodes,
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original-zarr", required=True, type=Path)
    parser.add_argument("--output-zarr", required=True, type=Path)
    parser.add_argument("--work-dir", required=True, type=Path)
    parser.add_argument("--episodes", required=True, type=parse_episodes)
    parser.add_argument("--edge-feather-px", type=int, default=0)
    args = parser.parse_args()

    original_group = zarr.open_group(str(args.original_zarr), mode="r")
    output_group = zarr.open_group(str(args.output_zarr), mode="a")
    ends = np.asarray(original_group["meta/episode_ends"][:], dtype=int)
    starts = np.concatenate(([0], ends[:-1]))
    if not np.array_equal(ends, output_group["meta/episode_ends"][:]):
        raise ValueError("Original and output datasets have different episode boundaries.")

    source_rgb = original_group["data/head_camera"]
    output_rgb = output_group["data/head_camera"]
    for episode in args.episodes:
        if episode < 0 or episode >= len(ends):
            raise ValueError(f"Invalid episode {episode}")
        masks_path = args.work_dir / "masks" / f"episode_{episode:04d}.npz"
        background_path = args.work_dir / "edited_first_frames" / f"episode_{episode:04d}.png"
        if not masks_path.is_file() or not background_path.is_file():
            raise FileNotFoundError(f"Missing mask or edited background for episode {episode}")
        masks = np.load(masks_path)
        required = ("hammer", "green_cube", "right_arm")
        if any(name not in masks for name in required):
            raise ValueError(f"Episode {episode} predates right-arm masks; rerun it instead.")
        start, end = int(starts[episode]), int(ends[episode])
        original = chw_to_hwc(np.asarray(source_rgb[start:end], dtype=np.uint8))
        background = np.asarray(Image.open(background_path).convert("RGB"), dtype=np.uint8)
        core_mask = masks["hammer"] | masks["green_cube"] | masks["right_arm"]
        if core_mask.shape != original.shape[:3]:
            raise ValueError(f"Mask shape mismatch for episode {episode}: {core_mask.shape}")
        final, alpha = composite_background(original, background, core_mask, args.edge_feather_px)
        if not np.array_equal(final[core_mask], original[core_mask]):
            raise RuntimeError(f"Core protected pixels changed for episode {episode}")
        output_rgb[start:end] = hwc_to_chw(final)
        draw_qa(
            original,
            background,
            final,
            alpha > 0,
            args.work_dir / "qa" / f"episode_{episode:04d}.jpg",
            f"recomposed | red = protected hammer/cube/right arm",
        )
        print(f"episode {episode:04d}: recomposed with {args.edge_feather_px}px edge feather")


if __name__ == "__main__":
    main()
