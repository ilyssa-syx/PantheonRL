# RobotWin RGB domain-edit pipeline

This pipeline augments only \`data/head_camera\` in an existing RobotWin Zarr
dataset. It deliberately leaves actions, states, and episode boundaries
unchanged.

For each episode it:

1. deterministically selects exactly one visual domain (\`table_texture\`,
   \`tabletop_object\`, or \`table_size\`);
2. asks Seedream 4.5 to make a clean edited tabletop background plate from the
   first RGB frame, removing the moving right arm, hammer, and green cube;
3. uses native SAM 3 video segmentation for the \`hammer\`, \`green cube\`,
   and hammer-holding \`right arm\` on the original video;
4. composites the original pixels under the union of those masks over the clean
   edited background plate. By default, every pixel outside the mask is 100%
   Seedream background; optional edge feathering can be enabled explicitly.

\`table_size\` is an image-space change only. It does not re-simulate physics,
actions, robot kinematics, or contact states.

## Setup

The implementation runs in the already-installed SAM 3 environment. Zarr v2
is its only extra Python dependency.

\`\`\`bash
conda activate sam3
python -m pip install -r /workspace/Assignment4/rgb_edit_pipeline/requirements.txt
\`\`\`

The tracker uses the local checkpoint by default:
\`/workspace/models/sam3/checkpoints/sam3.pt\`.

The Seedream client uses the official \`volcenginesdkarkruntime.Ark\` SDK with
the Beijing Ark v3 endpoint. It reads exactly one API key from \`ARK_API_KEY\`,
matching the official Seedream example. Credentials are never written to output
files or logs.

## Safe first run

Dry-run prints the sampled edit for episode zero and does not create files or
call either model:

\`\`\`bash
conda run -n sam3 python /workspace/Assignment4/rgb_edit_pipeline/run_rgb_edit.py \\
  --input-zarr /workspace/Assignment4/final_robotwin_keep100_right8.zarr \\
  --output-zarr /workspace/Assignment4/final_robotwin_keep100_right8_rgbedit.zarr \\
  --episodes 0 --dry-run
\`\`\`

Run SAM 3 and compositing without a paid Seedream request. The first frame is
used as an unchanged static background, which makes this a good tracking and
output-format test:

\`\`\`bash
conda run -n sam3 python /workspace/Assignment4/rgb_edit_pipeline/run_rgb_edit.py \\
  --input-zarr /workspace/Assignment4/final_robotwin_keep100_right8.zarr \\
  --output-zarr /workspace/Assignment4/final_robotwin_keep100_right8_rgbedit.zarr \\
  --episodes 0 --save-masks
\`\`\`

Use Seedream on a small pilot only after inspecting the no-API output:

\`\`\`bash
conda run -n sam3 python /workspace/Assignment4/rgb_edit_pipeline/run_rgb_edit.py \\
  --input-zarr /workspace/Assignment4/final_robotwin_keep100_right8.zarr \\
  --output-zarr /workspace/Assignment4/final_robotwin_keep100_right8_rgbedit.zarr \\
  --episodes 0,1,2,3,4,5,6,7 --use-seedream --save-masks
\`\`\`

The command refuses to process all episodes unless \`--all-episodes\` is
explicitly given. It is resumable: completed episodes are read from the JSONL
manifest and skipped on later runs.

## SAM2 manual-point flow

The SAM2 variant opens a manual point UI first. Points are saved automatically
after every click, undo, or clear. After placing points for a target, use the
preview button to inspect its propagated SAM2 mask; previewed masks are cached
and reused by the final generation as long as the points have not changed. Add
positive or negative points until each target mask looks right, then press
Ctrl-C in the terminal to continue:

\`\`\`bash
/workspace/Assignment4/rgb_edit_pipeline/run_rgb_edit_sam2_pipeline.sh \\
  --input-zarr /workspace/Assignment4/final_robotwin_keep100_right8.zarr \\
  --output-zarr /workspace/Assignment4/final_robotwin_keep100_right8_pilot5_sam2.zarr \\
  --episodes 0-4 \\
  --use-seedream \\
  --save-masks
\`\`\`

When running on a remote server, forward the UI port from your local machine:

\`\`\`bash
ssh -N -L 7862:127.0.0.1:7862 USER@SERVER
\`\`\`

## Outputs

For an output dataset \`foo.zarr\`, runtime artefacts live in
\`foo_rgbedit_work/\`:

- \`manifest.jsonl\`: domain choice, prompt, API result metadata, mask statistics,
  and episode status. It intentionally contains no secret values.
- \`edited_first_frames/\`: normalized Seedream first frames.
- \`qa/\`: six-panel contact sheets (original, edited, masks, and composites).
- \`masks/\`: optional compressed mask arrays, when \`--save-masks\` is used.

The final dataset has the exact source arrays and chunking for \`action\`,
\`state\`, and \`episode_ends\`; only \`data/head_camera\` contains new RGB
values.

## Recovery

If the process exits after a partial Zarr write, rerun exactly the same
command. An episode is marked completed only after all of its RGB frames and
QA artefacts were written, so it will be regenerated. Do not run two writers
against the same output Zarr concurrently.
