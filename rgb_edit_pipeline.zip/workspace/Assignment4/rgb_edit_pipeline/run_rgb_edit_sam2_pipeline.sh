#!/usr/bin/env bash

set -euo pipefail

PIPELINE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

SAM2_CONDA_ENV="${SAM2_CONDA_ENV:-sam2}"
CONDA_EXE="${CONDA_EXE:-}"
ANNOTATOR_HOST="${ANNOTATOR_HOST:-127.0.0.1}"
ANNOTATOR_PORT="${ANNOTATOR_PORT:-7862}"
ANNOTATOR_DEVICE="${ANNOTATOR_DEVICE:-cuda}"
PREVIEW_MAX_FRAMES="${PREVIEW_MAX_FRAMES:-0}"
DRY_RUN="${DRY_RUN:-0}"

usage() {
  cat <<EOF
Usage:
  $0 --input-zarr INPUT.zarr --output-zarr OUTPUT.zarr --episodes 0-4 [options]

Runs the SAM2 RGB edit flow:
  1. Open a browser UI for manual SAM2 points.
  2. Points are saved automatically; preview masks are cached automatically.
  3. Press Ctrl-C in this terminal to continue.
  4. Run run_rgb_edit_sam2.py with the saved points JSON and cached masks.

Common options:
  --points-json PATH       Default: OUTPUT_sam2_points.json
  --mask-cache-dir PATH    Default: OUTPUT_sam2_mask_cache
  --host HOST              UI bind host. Default: $ANNOTATOR_HOST
  --port PORT              UI port. Default: $ANNOTATOR_PORT
  --device DEVICE          SAM2 preview device. Default: $ANNOTATOR_DEVICE
  --preview-max-frames N   Preview first N frames only. Default: all frames
  --share                  Create a public Gradio link for collaborators
  --use-seedream           Forwarded to run_rgb_edit_sam2.py
  --save-masks             Forwarded to run_rgb_edit_sam2.py
  --overwrite-output       Forwarded to run_rgb_edit_sam2.py

Forward port from your local machine when running remotely:
  ssh -N -L $ANNOTATOR_PORT:127.0.0.1:$ANNOTATOR_PORT USER@SERVER
EOF
}

die() {
  echo "[rgb_edit_sam2_pipeline] ERROR: $*" >&2
  exit 1
}

log() {
  echo "[rgb_edit_sam2_pipeline] $*"
}

print_cmd() {
  printf '[rgb_edit_sam2_pipeline] command:'
  printf ' %q' "$@"
  printf '\n'
}

run_cmd() {
  print_cmd "$@"
  if [[ "$DRY_RUN" == "1" ]]; then
    return 0
  fi
  "$@"
}

resolve_conda_executable() {
  if [[ -n "$CONDA_EXE" ]]; then
    [[ -f "$CONDA_EXE" ]] || die "CONDA_EXE does not exist: $CONDA_EXE"
    return 0
  fi

  local candidate
  for candidate in /root/miniforge3/bin/conda /opt/conda/bin/conda; do
    if [[ -f "$candidate" ]]; then
      CONDA_EXE="$candidate"
      return 0
    fi
  done

  if CONDA_EXE="$(command -v conda 2>/dev/null)"; then
    return 0
  fi

  die "Could not find conda. Set CONDA_EXE=/path/to/conda."
}

current_env_matches() {
  local env_name=$1
  local prefix_name=""
  if [[ -n "${CONDA_PREFIX:-}" ]]; then
    prefix_name="$(basename "$CONDA_PREFIX")"
  fi
  [[ "${CONDA_DEFAULT_ENV:-}" == "$env_name" || "$prefix_name" == "$env_name" ]]
}

python_cmd_for_env() {
  local env_name=$1
  shift
  if current_env_matches "$env_name"; then
    PYTHON_CMD=(python "$@")
  else
    PYTHON_CMD=("$CONDA_EXE" run --no-capture-output -n "$env_name" python "$@")
  fi
}

run_interruptible_python_env() {
  local env_name=$1
  shift
  if [[ "$DRY_RUN" == "1" ]]; then
    python_cmd_for_env "$env_name" "$@"
    run_cmd "${PYTHON_CMD[@]}"
    return 0
  fi

  python_cmd_for_env "$env_name" "$@"
  print_cmd "${PYTHON_CMD[@]}"

  set +e
  local child_pid
  local status
  local interrupted=0
  local kill_target
  if command -v setsid >/dev/null 2>&1; then
    setsid "${PYTHON_CMD[@]}" &
    child_pid=$!
    kill_target="-$child_pid"
  else
    "${PYTHON_CMD[@]}" &
    child_pid=$!
    kill_target="$child_pid"
  fi
  trap 'interrupted=1; echo; echo "[rgb_edit_sam2_pipeline] Ctrl-C received; stopping annotation UI and continuing."; kill -INT "$kill_target" 2>/dev/null' INT
  wait "$child_pid"
  status=$?
  if [[ "$interrupted" == "1" ]]; then
    sleep 1
    kill -TERM "$kill_target" 2>/dev/null
    wait "$child_pid" 2>/dev/null
    status=130
  fi
  trap - INT
  set -e

  if [[ "$status" -ne 0 && "$status" -ne 130 ]]; then
    die "Interruptible command exited with status $status"
  fi
}

INPUT_ZARR=""
OUTPUT_ZARR=""
EPISODES=""
POINTS_JSON=""
MASK_CACHE_DIR=""
RUN_ARGS=()
ANNOTATOR_ARGS=()

while [[ "$#" -gt 0 ]]; do
  case "$1" in
    -h|--help)
      usage
      exit 0
      ;;
    --input-zarr)
      [[ "$#" -ge 2 ]] || die "--input-zarr needs a value"
      INPUT_ZARR=$2
      RUN_ARGS+=("$1" "$2")
      shift 2
      ;;
    --output-zarr)
      [[ "$#" -ge 2 ]] || die "--output-zarr needs a value"
      OUTPUT_ZARR=$2
      RUN_ARGS+=("$1" "$2")
      shift 2
      ;;
    --episodes)
      [[ "$#" -ge 2 ]] || die "--episodes needs a value"
      EPISODES=$2
      RUN_ARGS+=("$1" "$2")
      shift 2
      ;;
    --points-json)
      [[ "$#" -ge 2 ]] || die "--points-json needs a value"
      POINTS_JSON=$2
      shift 2
      ;;
    --mask-cache-dir)
      [[ "$#" -ge 2 ]] || die "--mask-cache-dir needs a value"
      MASK_CACHE_DIR=$2
      shift 2
      ;;
    --sam2-checkpoint|--sam2-config)
      [[ "$#" -ge 2 ]] || die "$1 needs a value"
      RUN_ARGS+=("$1" "$2")
      ANNOTATOR_ARGS+=("$1" "$2")
      shift 2
      ;;
    --host)
      [[ "$#" -ge 2 ]] || die "--host needs a value"
      ANNOTATOR_HOST=$2
      shift 2
      ;;
    --port)
      [[ "$#" -ge 2 ]] || die "--port needs a value"
      ANNOTATOR_PORT=$2
      shift 2
      ;;
    --device)
      [[ "$#" -ge 2 ]] || die "--device needs a value"
      ANNOTATOR_DEVICE=$2
      shift 2
      ;;
    --preview-max-frames)
      [[ "$#" -ge 2 ]] || die "--preview-max-frames needs a value"
      PREVIEW_MAX_FRAMES=$2
      shift 2
      ;;
    --share)
      ANNOTATOR_ARGS+=("$1")
      shift
      ;;
    --all-episodes)
      die "This wrapper needs an explicit --episodes range for the annotation UI."
      ;;
    *)
      RUN_ARGS+=("$1")
      shift
      ;;
  esac
done

[[ -n "$INPUT_ZARR" ]] || die "--input-zarr is required"
[[ -n "$OUTPUT_ZARR" ]] || die "--output-zarr is required"
[[ -n "$EPISODES" ]] || die "--episodes is required"

if [[ -z "$POINTS_JSON" ]]; then
  output_base="${OUTPUT_ZARR%/}"
  output_base="${output_base%.zarr}"
  POINTS_JSON="${output_base}_sam2_points.json"
fi
if [[ -z "$MASK_CACHE_DIR" ]]; then
  output_base="${OUTPUT_ZARR%/}"
  output_base="${output_base%.zarr}"
  MASK_CACHE_DIR="${output_base}_sam2_mask_cache"
fi

resolve_conda_executable

log "Launching SAM2 point annotation UI."
log "Open http://$ANNOTATOR_HOST:$ANNOTATOR_PORT after forwarding the port, then save all points."
log "When the JSON is saved, press Ctrl-C in this terminal to continue to SAM2 generation."
run_interruptible_python_env "$SAM2_CONDA_ENV" \
  "$PIPELINE_DIR/sam2_point_annotator.py" \
  --input-zarr "$INPUT_ZARR" \
  --episodes "$EPISODES" \
  --output-json "$POINTS_JSON" \
  --host "$ANNOTATOR_HOST" \
  --port "$ANNOTATOR_PORT" \
  --device "$ANNOTATOR_DEVICE" \
  --preview-max-frames "$PREVIEW_MAX_FRAMES" \
  --mask-cache-dir "$MASK_CACHE_DIR" \
  "${ANNOTATOR_ARGS[@]}"

if [[ ! -f "$POINTS_JSON" ]]; then
  die "Points JSON was not saved: $POINTS_JSON"
fi

log "Running SAM2 RGB edit with points JSON: $POINTS_JSON"
python_cmd_for_env "$SAM2_CONDA_ENV" \
  "$PIPELINE_DIR/run_rgb_edit_sam2.py" \
  "${RUN_ARGS[@]}" \
  --points-json "$POINTS_JSON" \
  --mask-cache-dir "$MASK_CACHE_DIR"
run_cmd "${PYTHON_CMD[@]}"
