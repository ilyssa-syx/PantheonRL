#!/usr/bin/env python3
"""Export an original-versus-edited RobotWin episode as a GIF and contact sheet."""

from __future__ import annotations

import argparse
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import zarr
from PIL import Image, ImageDraw


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original-zarr", required=True, type=Path)
    parser.add_argument("--edited-zarr", required=True, type=Path)
    parser.add_argument("--episode", type=int, default=0)
    parser.add_argument("--gif", required=True, type=Path)
    parser.add_argument("--edited-gif", type=Path, help="Standalone GIF of the generated RGB episode.")
    parser.add_argument("--edited-mp4", type=Path, help="Standalone H.264 MP4 of the generated RGB episode.")
    parser.add_argument("--contact-sheet", type=Path)
    parser.add_argument("--fps", type=float, default=8.0)
    parser.add_argument("--max-frames", type=int, default=0, help="0 keeps every frame")
    return parser.parse_args()


def episode_bounds(group: zarr.hierarchy.Group, episode: int) -> tuple[int, int]:
    ends = np.asarray(group["meta/episode_ends"][:], dtype=np.int64)
    if episode < 0 or episode >= len(ends):
        raise ValueError(f"episode must be from 0 to {len(ends) - 1}")
    return (0 if episode == 0 else int(ends[episode - 1])), int(ends[episode])


def to_image(frame: np.ndarray) -> Image.Image:
    return Image.fromarray(np.moveaxis(frame, 0, -1).astype(np.uint8), mode="RGB")


def paired_frame(original: np.ndarray, edited: np.ndarray, index: int) -> Image.Image:
    left, right = to_image(original), to_image(edited)
    width, height = left.size
    canvas = Image.new("RGB", (width * 2, height + 26), "black")
    canvas.paste(left, (0, 26))
    canvas.paste(right, (width, 26))
    draw = ImageDraw.Draw(canvas)
    draw.text((5, 6), f"original | frame {index}", fill="white")
    draw.text((width + 5, 6), "RGB edited + protected hammer/cube", fill="white")
    return canvas


def write_contact_sheet(frames: list[Image.Image], output: Path) -> None:
    cols = 3
    rows = (len(frames) + cols - 1) // cols
    width, height = frames[0].size
    canvas = Image.new("RGB", (cols * width, rows * height), "black")
    for position, frame in enumerate(frames):
        canvas.paste(frame, ((position % cols) * width, (position // cols) * height))
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output, quality=92)


def write_mp4(frames: list[Image.Image], output: Path, fps: float) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="robotwin_rgb_video_") as temporary:
        frame_pattern = Path(temporary) / "%05d.png"
        for index, frame in enumerate(frames):
            frame.save(Path(temporary) / f"{index:05d}.png")
        subprocess.run(
            [
                "ffmpeg", "-y", "-loglevel", "error", "-framerate", str(fps),
                "-i", str(frame_pattern), "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-movflags", "+faststart", str(output),
            ],
            check=True,
        )


def main() -> None:
    args = parse_args()
    if args.fps <= 0:
        raise ValueError("--fps must be positive")
    source = zarr.open_group(str(args.original_zarr), mode="r")
    edited = zarr.open_group(str(args.edited_zarr), mode="r")
    start, end = episode_bounds(source, args.episode)
    if not np.array_equal(source["meta/episode_ends"][:], edited["meta/episode_ends"][:]):
        raise ValueError("Original and edited datasets have different episode boundaries.")

    indices = np.arange(start, end)
    if args.max_frames and len(indices) > args.max_frames:
        indices = np.unique(np.linspace(start, end - 1, args.max_frames, dtype=np.int64))
    original_rgb = source["data/head_camera"]
    edited_rgb = edited["data/head_camera"]
    frames = [paired_frame(original_rgb[i], edited_rgb[i], int(i - start)) for i in indices]
    if not frames:
        raise ValueError("Episode contains no frames.")

    args.gif.parent.mkdir(parents=True, exist_ok=True)
    frames[0].save(
        args.gif,
        save_all=True,
        append_images=frames[1:],
        duration=round(1000 / args.fps),
        loop=0,
        disposal=2,
        optimize=False,
    )
    if args.edited_gif:
        generated_frames = [to_image(edited_rgb[i]) for i in indices]
        args.edited_gif.parent.mkdir(parents=True, exist_ok=True)
        generated_frames[0].save(
            args.edited_gif,
            save_all=True,
            append_images=generated_frames[1:],
            duration=round(1000 / args.fps),
            loop=0,
            disposal=2,
            optimize=False,
        )
    if args.edited_mp4:
        if not args.edited_gif:
            generated_frames = [to_image(edited_rgb[i]) for i in indices]
        write_mp4(generated_frames, args.edited_mp4, args.fps)
    if args.contact_sheet:
        positions = np.unique(np.linspace(0, len(frames) - 1, min(6, len(frames)), dtype=np.int64))
        write_contact_sheet([frames[int(position)] for position in positions], args.contact_sheet)
    print(f"GIF: {args.gif}")
    if args.edited_gif:
        print(f"Generated-RGB GIF: {args.edited_gif}")
    if args.edited_mp4:
        print(f"Generated-RGB MP4: {args.edited_mp4}")
    if args.contact_sheet:
        print(f"Contact sheet: {args.contact_sheet}")


if __name__ == "__main__":
    main()
