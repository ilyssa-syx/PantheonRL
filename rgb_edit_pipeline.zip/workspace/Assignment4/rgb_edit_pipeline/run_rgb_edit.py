#!/usr/bin/env python3
"""Seedream first-frame editing plus native SAM3 object preservation for RobotWin."""

from __future__ import annotations

import argparse
import base64
import gc
import hashlib
import json
import os
import random
import shutil
import sys
import tempfile
import time
from io import BytesIO
from pathlib import Path
from typing import Any

import numpy as np
import requests
import zarr
from PIL import Image, ImageDraw

SAM3_ROOT = Path("/workspace/models/sam3")
SAM3_CHECKPOINT = SAM3_ROOT / "checkpoints/sam3.pt"
ARK_BASE_URL = "https://ark.cn-beijing.volces.com/api/v3"
SEEDREAM_MODEL = "doubao-seedream-4-5-251128"
TARGETS = {
    # One semantic attempt is enough for these tiny objects; visual-instance
    # prompting below is the reliable SAM3 path when it misses.
    "hammer": ("hammer",),
    "green_cube": ("green cube", "green block", "small green block"),
    # Text grounding selects the tabletop for this small first-person robot.
    # Use the calibrated visual instance point on the right forearm instead.
    "right_arm": (),
}


class PipelineError(RuntimeError):
    pass


def episode_seed(seed: int, episode: int) -> int:
    payload = f"robotwin-rgbedit-v1:{seed}:{episode}".encode()
    return int.from_bytes(hashlib.blake2b(payload, digest_size=8).digest(), "little")


def choice_for_episode(seed: int, episode: int) -> dict[str, Any]:
    """Sample precisely one visual domain, with a fully reproducible prompt."""
    rng = random.Random(episode_seed(seed, episode))
    domain = rng.choice(("table_texture", "tabletop_object", "table_size"))
    common = (
        "This is a fixed first-person robot manipulation camera image. Create a clean, "
        "static background plate with the exact same camera viewpoint, room geometry, "
        "perspective, realistic lighting, and shadows. Remove the moving robot right arm "
        "and gripper visible at lower-right, the hammer, and the green cube. Seamlessly "
        "reconstruct all exposed tabletop regions beneath them; do not leave object "
        "silhouettes, duplicate objects, or residual shadows. Keep the left robot arm and "
        "all fixed scene structure unchanged. Make only the requested tabletop edit."
    )
    if domain == "table_texture":
        name, text = rng.choice((
            ("light_oak", "matte light-oak wood with subtle natural grain"),
            ("dark_walnut", "low-gloss dark walnut wood"),
            ("grey_laminate", "clean warm-grey laminate"),
            ("blue_antistatic_mat", "plain muted-blue anti-static work mat"),
            ("charcoal_rubber", "matte charcoal rubber workbench surface"),
        ))
        edit = f"Replace only the tabletop material with {text}. Keep its size and height unchanged."
        params = {"material": name}
    elif domain == "tabletop_object":
        name, text = rng.choice((
            ("white_notebook", "one small closed white notebook"),
            ("steel_tray", "one small empty brushed-steel parts tray"),
            ("kraft_box", "one small plain kraft cardboard box"),
            ("black_tape", "one small black tape roll"),
        ))
        location = rng.choice(("far back-left", "far back-right"))
        edit = f"Place {text} on the {location} tabletop edge, away from the hammer and green cube. Add nothing else."
        params = {"object": name, "location": location}
    elif domain == "table_size":
        length = rng.choice((-8, -6, 6, 8))
        width = rng.choice((-4, -3, 3, 4))
        edit = (
            "Change only the tabletop planform to look about "
            f"{abs(length)} cm {'shorter' if length < 0 else 'longer'} and "
            f"{abs(width)} cm {'narrower' if width < 0 else 'wider'}. Preserve its "
            "height, material, camera, robot, hammer, and cube."
        )
        params = {"length_delta_cm": length, "width_delta_cm": width}
    return {"domain": domain, "parameters": params, "prompt": common + "\n\nRequested edit: " + edit}


def chw_to_hwc(value: np.ndarray) -> np.ndarray:
    if value.ndim != 4 or value.shape[1] != 3:
        raise PipelineError(f"Expected RGB [T,3,H,W], found {value.shape}")
    return np.moveaxis(value, 1, -1)


def hwc_to_chw(value: np.ndarray) -> np.ndarray:
    return np.moveaxis(value, -1, 1)


def dilate_mask(mask: np.ndarray, radius: int) -> np.ndarray:
    """Dilate a [T,H,W] mask without an OpenCV dependency."""
    if radius <= 0:
        return mask
    padded = np.pad(mask, ((0, 0), (radius, radius), (radius, radius)), constant_values=False)
    result = np.zeros_like(mask)
    height, width = mask.shape[1:]
    for delta_y in range(2 * radius + 1):
        for delta_x in range(2 * radius + 1):
            result |= padded[:, delta_y:delta_y + height, delta_x:delta_x + width]
    return result


def feather_alpha(mask: np.ndarray, radius: int) -> np.ndarray:
    """Keep the mask core exact and softly blend only its outer edge."""
    alpha = mask.astype(np.float32)
    if radius <= 0:
        return alpha
    for distance in range(1, radius + 1):
        # A quickly decaying outer alpha avoids copying a visible ring of the
        # original tabletop onto a differently edited tabletop.
        opacity = ((radius + 1 - distance) / (radius + 1)) ** 2
        alpha = np.maximum(alpha, dilate_mask(mask, distance).astype(np.float32) * opacity)
    return alpha


def composite_background(
    original: np.ndarray,
    background: np.ndarray,
    core_mask: np.ndarray,
    edge_feather_px: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Composite a static background while preserving core-mask pixels exactly."""
    alpha = feather_alpha(core_mask, edge_feather_px)
    final = np.rint(
        original.astype(np.float32) * alpha[..., None]
        + background[None].astype(np.float32) * (1.0 - alpha[..., None])
    ).astype(np.uint8)
    return final, alpha


def build_ark_client() -> Any:
    """Construct Ark exactly with the API key from ARK_API_KEY."""
    from volcenginesdkarkruntime import Ark

    api_key = os.getenv("ARK_API_KEY")
    if not api_key:
        raise PipelineError("ARK_API_KEY is not set.")
    return Ark(base_url="https://ark.cn-beijing.volces.com/api/v3", api_key=api_key)


def data_url(image: np.ndarray) -> str:
    buffer = BytesIO()
    Image.fromarray(image).save(buffer, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode()


class Seedream:
    def __init__(self, timeout: int, model: str) -> None:
        try:
            self.client = build_ark_client()
        except ModuleNotFoundError as exc:
            raise PipelineError(
                "Missing official Ark SDK. Run: python -m pip install 'volcengine-python-sdk[ark]>=5.0.26'"
            ) from exc
        self.timeout = timeout
        self.model = model

    def edit(self, source: np.ndarray, prompt: str) -> tuple[np.ndarray, dict[str, Any]]:
        reference = data_url(source)
        try:
            response = self.client.images.generate(
                model=self.model,
                prompt=prompt,
                image=reference,
                size="2K",
                response_format="url",
                watermark=False,
                timeout=self.timeout,
            )
        except Exception as exc:
            raise PipelineError(f"Seedream SDK request failed: {type(exc).__name__}: {exc}") from exc

        data = getattr(response, "data", None)
        if not data:
            raise PipelineError("Seedream SDK response did not contain data.")
        item = data[0]
        raw: bytes | None = None
        encoded = getattr(item, "b64_json", None)
        if isinstance(encoded, str) and encoded:
            raw = base64.b64decode(encoded.split(",", 1)[-1])
        if raw is None:
            url = getattr(item, "url", None)
            if isinstance(url, str) and url:
                if url.startswith("data:image/"):
                    raw = base64.b64decode(url.split(",", 1)[-1])
                else:
                    image_response = requests.get(url, timeout=self.timeout)
                    image_response.raise_for_status()
                    raw = image_response.content
        if raw is None:
            raise PipelineError("Seedream SDK response did not include an image URL or base64 image.")
        try:
            edited = np.asarray(Image.open(BytesIO(raw)).convert("RGB"), dtype=np.uint8)
        except Exception as exc:
            raise PipelineError(f"Cannot decode Seedream image: {exc}") from exc
        h, w = source.shape[:2]
        if edited.shape[:2] != (h, w):
            edited = np.asarray(Image.fromarray(edited).resize((w, h), Image.Resampling.LANCZOS))
        metadata = {
            "model": str(getattr(response, "model", self.model)),
            "request_id": str(getattr(response, "id", "") or ""),
            "response_type": type(response).__name__,
        }
        return edited, metadata


def as_numpy(value: Any) -> np.ndarray:
    if hasattr(value, "detach"):
        return value.detach().cpu().numpy()
    return np.asarray(value)


def output_mask(outputs: dict[str, Any], height: int, width: int) -> np.ndarray:
    masks = outputs.get("out_binary_masks")
    if masks is None:
        return np.zeros((height, width), dtype=bool)
    masks = as_numpy(masks)
    if masks.size == 0:
        return np.zeros((height, width), dtype=bool)
    if masks.ndim == 2:
        masks = masks[None]
    if masks.ndim != 3:
        raise PipelineError(f"Unexpected SAM3 mask dimensions: {masks.shape}")
    if masks.shape[1:] != (height, width):
        masks = np.stack([
            np.asarray(
                Image.fromarray((mask > 0).astype(np.uint8) * 255).resize(
                    (width, height), Image.Resampling.NEAREST
                ),
                dtype=bool,
            )
            for mask in masks
        ])
    return np.any(masks.astype(bool), axis=0)


def normalized_box(x0: int, y0: int, x1: int, y1: int, height: int, width: int) -> list[float]:
    x0, x1 = max(0, x0), min(width, x1)
    y0, y1 = max(0, y0), min(height, y1)
    if x1 <= x0 or y1 <= y0:
        raise PipelineError(f"Invalid visual-prompt box: {(x0, y0, x1, y1)}")
    return [x0 / width, y0 / height, (x1 - x0) / width, (y1 - y0) / height]


def largest_component_box(mask: np.ndarray, padding: int) -> list[float] | None:
    """Return an XYWH-normalized box for the largest 8-connected binary component."""
    height, width = mask.shape
    seen = np.zeros_like(mask, dtype=bool)
    best: tuple[int, int, int, int, int] | None = None
    for start_y, start_x in np.argwhere(mask):
        if seen[start_y, start_x]:
            continue
        stack = [(int(start_y), int(start_x))]
        seen[start_y, start_x] = True
        area, min_y, max_y, min_x, max_x = 0, int(start_y), int(start_y), int(start_x), int(start_x)
        while stack:
            y, x = stack.pop()
            area += 1
            min_y, max_y = min(min_y, y), max(max_y, y)
            min_x, max_x = min(min_x, x), max(max_x, x)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < height and 0 <= nx < width and not seen[ny, nx] and mask[ny, nx]:
                        seen[ny, nx] = True
                        stack.append((ny, nx))
        if best is None or area > best[0]:
            best = (area, min_y, max_y, min_x, max_x)
    if best is None:
        return None
    _, min_y, max_y, min_x, max_x = best
    return normalized_box(min_x - padding, min_y - padding, max_x + padding + 1, max_y + padding + 1, height, width)


def green_cube_proposal(image: np.ndarray) -> list[float] | None:
    """A visual proposal for SAM3 when tiny open-vocabulary text grounding misses the cube."""
    red, green, blue = (image[..., channel].astype(np.int16) for channel in range(3))
    color = (green >= 65) & (green >= red + 20) & (green >= blue + 10)
    # The table is central in RobotWin head-camera images. Excluding wall/background
    # colours makes the proposal deterministic but does not create the final mask.
    height, width = color.shape
    roi = np.zeros_like(color)
    roi[int(height * 0.20):int(height * 0.92), int(width * 0.20):int(width * 0.82)] = True
    return largest_component_box(color & roi, padding=6)


def write_jpegs(frames: np.ndarray, directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    for index, frame in enumerate(frames):
        Image.fromarray(frame).save(directory / f"{index:05d}.jpg", quality=100, subsampling=0)


class Sam3:
    def __init__(self, checkpoint: Path, compile_model: bool) -> None:
        if not checkpoint.is_file():
            raise PipelineError(f"SAM3 checkpoint not found: {checkpoint}")
        if str(SAM3_ROOT) not in sys.path:
            sys.path.insert(0, str(SAM3_ROOT))
        try:
            import torch
            from sam3.model_builder import build_sam3_predictor
        except ModuleNotFoundError as exc:
            raise PipelineError("Run this script in the sam3 conda environment.") from exc
        if not torch.cuda.is_available():
            raise PipelineError("SAM3 requires a CUDA-visible GPU.")
        self.torch = torch
        self.predictor = build_sam3_predictor(
            checkpoint_path=str(checkpoint),
            version="sam3",
            compile=compile_model,
            warm_up=False,
            async_loading_frames=False,
        )

    def track_once(
        self,
        frames_dir: Path,
        text: str | None,
        length: int,
        height: int,
        width: int,
        threshold: float,
        box: list[float] | None = None,
        point: list[float] | None = None,
        negative_point: list[float] | None = None,
        obj_id: int | None = None,
    ) -> np.ndarray:
        masks = np.zeros((length, height, width), dtype=bool)
        session_id: str | None = None
        try:
            session = self.predictor.handle_request({
                "type": "start_session",
                "resource_path": str(frames_dir),
                "offload_video_to_cpu": True,
            })
            session_id = str(session["session_id"])
            request: dict[str, Any] = {
                "type": "add_prompt",
                "session_id": session_id,
                "frame_index": 0,
                "output_prob_thresh": threshold,
            }
            if text is not None:
                request["text"] = text
            if box is not None:
                request["bounding_boxes"] = [box]
                request["bounding_box_labels"] = [1]
            if point is not None:
                request["points"] = [point] + ([negative_point] if negative_point is not None else [])
                request["point_labels"] = [1] + ([0] if negative_point is not None else [])
                request["obj_id"] = obj_id
            initial = self.predictor.handle_request(request)
            masks[0] |= output_mask(initial.get("outputs", {}), height, width)
            # Text grounding can fail for these tiny objects. Do not waste a full
            # propagation pass before trying the next text phrase or a visual prompt.
            if not masks[0].any():
                return masks
            for result in self.predictor.handle_stream_request({
                "type": "propagate_in_video",
                "session_id": session_id,
                "propagation_direction": "forward",
                "start_frame_index": 0,
                "max_frame_num_to_track": length,
                "output_prob_thresh": threshold,
            }):
                frame = int(result["frame_index"])
                if 0 <= frame < length:
                    masks[frame] |= output_mask(result.get("outputs", {}), height, width)
        except Exception as exc:
            raise PipelineError(f"SAM3 failed for {text or 'visual prompt'!r}: {exc}") from exc
        finally:
            if session_id:
                try:
                    self.predictor.handle_request({
                        "type": "close_session",
                        "session_id": session_id,
                        "run_gc_collect": False,
                    })
                except Exception:
                    pass
        return masks

    def track_target(
        self,
        frames_dir: Path,
        target: str,
        candidates: tuple[str, ...],
        length: int,
        height: int,
        width: int,
        threshold: float,
        fallback_box: list[float] | None,
    ) -> tuple[np.ndarray, str]:
        maximum_first_area = {
            "hammer": 1200,
            "green_cube": 1200,
            "right_arm": 5000,
        }[target]

        def credible(masks: np.ndarray, source: str) -> bool:
            first_area = int(masks[0].sum())
            if not first_area:
                return False
            if first_area > maximum_first_area:
                print(
                    f"SAM3 target={target} source={source} rejected first_area={first_area} "
                    f"(maximum={maximum_first_area}; likely tabletop/background)",
                    flush=True,
                )
                return False
            return True

        for prompt in candidates:
            masks = self.track_once(frames_dir, prompt, length, height, width, threshold)
            first_area = int(masks[0].sum())
            print(f"SAM3 target={target} prompt={prompt!r} first_area={first_area}", flush=True)
            if credible(masks, f"text:{prompt}"):
                return masks, prompt
        if fallback_box is not None:
            point = [fallback_box[0] + fallback_box[2] / 2, fallback_box[1] + fallback_box[3] / 2]
            # A positive point on the tiny hammer alone can cause SAM3 to select
            # the white tabletop.  A nearby negative table point separates it.
            negative_point = (
                [min(0.99, point[0] + 0.04), min(0.99, point[1] + 0.05)]
                if target == "hammer" else None
            )
            masks = self.track_once(
                frames_dir,
                None,
                length,
                height,
                width,
                threshold,
                point=point,
                negative_point=negative_point,
                obj_id={"hammer": 100, "green_cube": 101, "right_arm": 102}[target],
            )
            first_area = int(masks[0].sum())
            print(
                f"SAM3 target={target} instance_point={point} negative_point={negative_point} "
                f"first_area={first_area}",
                flush=True,
            )
            if credible(masks, "instance_point"):
                return masks, "instance_point"
        raise PipelineError(
            f"SAM3 found no credible {target!r} mask using prompts: {', '.join(candidates)}"
        )

    def close(self) -> None:
        self.predictor = None
        gc.collect()
        self.torch.cuda.empty_cache()


def clone_array(src: Any, dst_group: Any, name: str) -> Any:
    dst = dst_group.create_dataset(
        name,
        shape=src.shape,
        chunks=src.chunks,
        dtype=src.dtype,
        compressor=src.compressor,
        filters=src.filters,
        fill_value=src.fill_value,
        order=src.order,
    )
    step = src.chunks[0] if src.ndim and src.chunks else 1
    if src.ndim == 0:
        dst[...] = src[...]
    else:
        for start in range(0, src.shape[0], step):
            dst[start:min(start + step, src.shape[0])] = src[start:min(start + step, src.shape[0])]
    dst.attrs.update(dict(src.attrs))
    return dst


def setup_output(input_path: Path, output_path: Path, overwrite: bool) -> tuple[Any, Any]:
    if output_path.exists() and overwrite:
        shutil.rmtree(output_path)
    src = zarr.open_group(str(input_path), mode="r")
    if output_path.exists() and (output_path / ".zgroup").is_file():
        dst = zarr.open_group(str(output_path), mode="a")
        if "data/head_camera" not in dst:
            raise PipelineError("Existing output zarr does not have data/head_camera.")
        return src, dst
    if output_path.exists() and any(output_path.iterdir()):
        raise PipelineError("Output path exists; choose a new one or pass --overwrite-output.")
    output_path.mkdir(parents=True, exist_ok=True)
    dst = zarr.open_group(str(output_path), mode="w")
    dst.attrs.update(dict(src.attrs))
    data = dst.require_group("data")
    meta = dst.require_group("meta")
    for name in ("action", "state"):
        clone_array(src[f"data/{name}"], data, name)
    clone_array(src["meta/episode_ends"], meta, "episode_ends")
    source_rgb = src["data/head_camera"]
    output_rgb = data.create_dataset(
        "head_camera",
        shape=source_rgb.shape,
        chunks=source_rgb.chunks,
        dtype=source_rgb.dtype,
        compressor=source_rgb.compressor,
        filters=source_rgb.filters,
        fill_value=source_rgb.fill_value,
        order=source_rgb.order,
    )
    output_rgb.attrs.update(dict(source_rgb.attrs))
    return src, dst


def append_jsonl(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n")


def completed_episodes(path: Path) -> set[int]:
    if not path.is_file():
        return set()
    found: set[int] = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if item.get("status") == "completed" and isinstance(item.get("episode"), int):
            found.add(item["episode"])
    return found


def parse_episodes(value: str) -> list[int]:
    answer: list[int] = []
    for token in value.split(","):
        token = token.strip()
        if not token:
            continue
        if "-" in token:
            lo, hi = (int(part) for part in token.split("-", 1))
            if hi < lo:
                raise argparse.ArgumentTypeError(f"Invalid range: {token}")
            answer.extend(range(lo, hi + 1))
        else:
            answer.append(int(token))
    return sorted(set(answer))


def parse_box(value: str) -> list[float]:
    try:
        box = [float(part.strip()) for part in value.split(",")]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("A box must be xmin,ymin,width,height in [0,1].") from exc
    if len(box) != 4 or any(number < 0 or number > 1 for number in box) or box[2] <= 0 or box[3] <= 0:
        raise argparse.ArgumentTypeError("A box must be xmin,ymin,width,height in [0,1].")
    return box


def draw_qa(
    original: np.ndarray,
    edited: np.ndarray,
    final: np.ndarray,
    mask: np.ndarray,
    output: Path,
    title: str,
) -> None:
    h, w = edited.shape[:2]
    overlay = original[0].astype(np.float32).copy()
    overlay[mask[0]] = overlay[mask[0]] * 0.5 + np.array([255, 30, 30]) * 0.5
    canvas = Image.new("RGB", (w * 3, h + 24), "white")
    draw = ImageDraw.Draw(canvas)
    draw.text((4, 4), title, fill="black")
    for index, (label, image) in enumerate((
        ("original f0", original[0]), ("edited f0", edited), ("final f0", final[0])
    )):
        x = index * w
        canvas.paste(Image.fromarray(image), (x, 24))
        draw.text((x + 4, 28), label, fill="yellow", stroke_width=1, stroke_fill="black")
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output)
    Image.fromarray(overlay.astype(np.uint8)).save(output.with_name(output.stem + "_mask.png"))


def run_episode(
    *,
    index: int,
    start: int,
    end: int,
    input_rgb: Any,
    output_rgb: Any,
    tracker: Sam3,
    choice: dict[str, Any],
    work: Path,
    seedream: Seedream | None,
    save_masks: bool,
    sam3_threshold: float,
    hammer_box: list[float],
    right_arm_box: list[float],
    mask_dilation_px: int,
) -> dict[str, Any]:
    original = chw_to_hwc(np.asarray(input_rgb[start:end], dtype=np.uint8))
    if len(original) == 0:
        raise PipelineError(f"Episode {index} has no frames.")

    # Make the external call before loading SAM3. A disabled Ark model should
    # fail fast instead of spending a full GPU tracking pass for this episode.
    metadata: dict[str, Any] | None = None
    if seedream:
        edited, metadata = seedream.edit(original[0], choice["prompt"])
        source = "seedream"
    else:
        edited, source = original[0].copy(), "original_first_frame_sam3_validation"

    frames_parent = work / "tmp_frames"
    frames_parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=f"episode_{index:04d}_", dir=frames_parent) as temporary:
        frames_dir = Path(temporary)
        write_jpegs(original, frames_dir)
        hammer, hammer_prompt = tracker.track_target(
            frames_dir, "hammer", TARGETS["hammer"], len(original), *original.shape[1:3],
            sam3_threshold, hammer_box,
        )
        cube_box = green_cube_proposal(original[0])
        cube, cube_prompt = tracker.track_target(
            frames_dir, "green_cube", TARGETS["green_cube"], len(original), *original.shape[1:3],
            sam3_threshold, cube_box,
        )
        right_arm, right_arm_prompt = tracker.track_target(
            frames_dir, "right_arm", TARGETS["right_arm"], len(original), *original.shape[1:3],
            sam3_threshold, right_arm_box,
        )
    core_protected = hammer | cube | right_arm
    final, alpha = composite_background(original, edited, core_protected, mask_dilation_px)
    if not np.array_equal(final[core_protected], original[core_protected]):
        raise PipelineError(f"Episode {index}: protected pixels changed during compositing.")
    output_rgb[start:end] = hwc_to_chw(final)

    edited_dir = work / "edited_first_frames"
    edited_dir.mkdir(parents=True, exist_ok=True)
    Image.fromarray(edited).save(edited_dir / f"episode_{index:04d}.png")
    draw_qa(
        original, edited, final, alpha > 0,
        work / "qa" / f"episode_{index:04d}.jpg",
        f"{choice['domain']} | red = protected hammer/cube/right arm",
    )
    if save_masks:
        mask_dir = work / "masks"
        mask_dir.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            mask_dir / f"episode_{index:04d}.npz",
            hammer=hammer,
            green_cube=cube,
            right_arm=right_arm,
        )
    return {
        "frames": len(original),
        "edit_source": source,
        "seedream": metadata,
        "hammer_first_area": int(hammer[0].sum()),
        "cube_first_area": int(cube[0].sum()),
        "right_arm_first_area": int(right_arm[0].sum()),
        "sam3_prompts": {
            "hammer": hammer_prompt,
            "green_cube": cube_prompt,
            "right_arm": right_arm_prompt,
        },
        "sam3_visual_boxes": {
            "hammer": hammer_box,
            "green_cube": cube_box,
            "right_arm": right_arm_box,
        },
        "hammer_missing_frames": int((~hammer.reshape(len(hammer), -1).any(1)).sum()),
        "cube_missing_frames": int((~cube.reshape(len(cube), -1).any(1)).sum()),
        "right_arm_missing_frames": int((~right_arm.reshape(len(right_arm), -1).any(1)).sum()),
        "mask_edge_feather_px": mask_dilation_px,
    }


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--input-zarr", required=True, type=Path)
    result.add_argument("--output-zarr", required=True, type=Path)
    selected = result.add_mutually_exclusive_group(required=True)
    selected.add_argument("--episodes", type=parse_episodes, help="For example: 0,2,10-12")
    selected.add_argument("--all-episodes", action="store_true")
    result.add_argument("--seed", type=int, default=20260620)
    result.add_argument("--dry-run", action="store_true")
    result.add_argument("--use-seedream", action="store_true")
    result.add_argument("--seedream-model", default=SEEDREAM_MODEL)
    result.add_argument("--seedream-timeout", type=int, default=300)
    result.add_argument("--sam3-checkpoint", type=Path, default=SAM3_CHECKPOINT)
    result.add_argument("--sam3-compile", action="store_true")
    result.add_argument(
        "--sam3-threshold",
        type=float,
        default=0.0,
        help="SAM3 binary-mask threshold. 0.0 retains small task objects better than the UI default.",
    )
    result.add_argument(
        "--hammer-box",
        type=parse_box,
        default=[0.49, 0.55, 0.06, 0.16],
        help="Fallback SAM3 visual prompt, as normalized xmin,ymin,width,height.",
    )
    result.add_argument(
        "--right-arm-box",
        type=parse_box,
        default=[0.62, 0.84, 0.12, 0.14],
        help="SAM3 right-arm visual prompt box; its centre is the calibrated positive point.",
    )
    result.add_argument(
        "--mask-dilation-px",
        type=int,
        default=0,
        help="Optional outer feather pixels; 0 keeps every pixel outside the mask 100% Seedream background.",
    )
    result.add_argument("--save-masks", action="store_true")
    result.add_argument("--overwrite-output", action="store_true")
    return result


def main() -> int:
    args = parser().parse_args()
    input_path, output_path = args.input_zarr.resolve(), args.output_zarr.resolve()
    if input_path == output_path:
        raise PipelineError("Input and output zarr paths must differ.")
    if not (input_path / ".zgroup").is_file():
        raise PipelineError(f"Not a Zarr v2 group: {input_path}")
    preview = zarr.open_group(str(input_path), mode="r")
    if "data/head_camera" not in preview or "meta/episode_ends" not in preview:
        raise PipelineError("Expected data/head_camera and meta/episode_ends.")
    ends = np.asarray(preview["meta/episode_ends"][:], dtype=int)
    starts = np.concatenate(([0], ends[:-1]))
    count = len(ends)
    episodes = list(range(count)) if args.all_episodes else args.episodes
    assert episodes is not None
    invalid = [item for item in episodes if item < 0 or item >= count]
    if invalid:
        raise PipelineError(f"Invalid episode ids (valid 0 to {count - 1}): {invalid}")

    print(f"input={input_path}")
    print(f"output={output_path}")
    for index in episodes:
        selected = choice_for_episode(args.seed, index)
        print(f"episode={index:04d} domain={selected['domain']} params={selected['parameters']}")
        if args.dry_run:
            print(selected["prompt"])
    if args.dry_run:
        return 0

    work = output_path.with_name(output_path.stem + "_rgbedit_work")
    manifest = work / "manifest.jsonl"
    done = completed_episodes(manifest)
    source, destination = setup_output(input_path, output_path, args.overwrite_output)
    input_rgb, output_rgb = source["data/head_camera"], destination["data/head_camera"]
    work.mkdir(parents=True, exist_ok=True)
    (work / "run_config.json").write_text(json.dumps({
        "input_zarr": str(input_path),
        "output_zarr": str(output_path),
        "seed": args.seed,
        "uses_seedream": args.use_seedream,
        "seedream_model": args.seedream_model if args.use_seedream else None,
        "sam3_checkpoint": str(args.sam3_checkpoint),
        "right_arm_box": args.right_arm_box,
        "mask_dilation_px": args.mask_dilation_px,
    }, indent=2) + "\n", encoding="utf-8")

    seedream = Seedream(args.seedream_timeout, args.seedream_model) if args.use_seedream else None
    tracker = Sam3(args.sam3_checkpoint.resolve(), args.sam3_compile)
    try:
        for index in episodes:
            if index in done:
                print(f"episode={index:04d} completed already; skip")
                continue
            choice = choice_for_episode(args.seed, index)
            record = {
                "episode": index,
                "start_frame": int(starts[index]),
                "end_frame": int(ends[index]),
                "domain": choice,
                "started_at_unix": time.time(),
            }
            append_jsonl(manifest, {**record, "status": "running"})
            try:
                result = run_episode(
                    index=index,
                    start=int(starts[index]),
                    end=int(ends[index]),
                    input_rgb=input_rgb,
                    output_rgb=output_rgb,
                    tracker=tracker,
                    choice=choice,
                    work=work,
                    seedream=seedream,
                    save_masks=args.save_masks,
                    sam3_threshold=args.sam3_threshold,
                    hammer_box=args.hammer_box,
                    right_arm_box=args.right_arm_box,
                    mask_dilation_px=args.mask_dilation_px,
                )
                append_jsonl(manifest, {
                    **record, **result, "status": "completed", "finished_at_unix": time.time()
                })
                print(f"episode={index:04d} completed")
            except Exception as exc:
                append_jsonl(manifest, {
                    **record, "status": "failed", "finished_at_unix": time.time(),
                    "error": f"{type(exc).__name__}: {exc}",
                })
                raise
    finally:
        tracker.close()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except PipelineError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
